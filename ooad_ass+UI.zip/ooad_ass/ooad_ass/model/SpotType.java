package model;

public enum SpotType {
    COMPACT,
    REGULAR,
    HANDICAPPED,
    RESERVED
}