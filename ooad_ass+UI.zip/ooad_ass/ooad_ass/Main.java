
import javax.swing.SwingUtilities;
import ui.ParkingSystemUI;

public class Main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ParkingSystemUI();
        });
    }
}
