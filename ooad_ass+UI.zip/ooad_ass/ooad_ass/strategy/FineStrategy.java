package strategy;

public interface FineStrategy {
    double calculateFine(double hoursOverstayed);
}