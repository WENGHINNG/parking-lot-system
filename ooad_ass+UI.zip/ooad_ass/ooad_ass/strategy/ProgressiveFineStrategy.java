package strategy;

public class ProgressiveFineStrategy implements FineStrategy {
    @Override
    public double calculateFine(double hoursOverstayed) {
        if (hoursOverstayed <= 0)
            return 0.0;

        if (hoursOverstayed <= 24) {
            return 50.0;
        } else if (hoursOverstayed <= 48) {
            return 50.0 + 100.0;
        } else if (hoursOverstayed <= 72) {
            return 50.0 + 100.0 + 150.0;
        } else {
            return 50.0 + 100.0 + 150.0 + 200.0;
        }
    }
}