package ui;

import javax.swing.*;

public class ParkingSystemUI extends JFrame {

    public ParkingSystemUI() {

        setTitle("Parking Lot Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.addTab("Entry", new EntryPanel());
        tabbedPane.addTab("Exit", new ExitPanel());

        add(tabbedPane);

        setVisible(true);
    }
}
