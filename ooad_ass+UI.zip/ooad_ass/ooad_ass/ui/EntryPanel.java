package ui;

import controller.ParkingLot;
import java.awt.*;
import javax.swing.*;
import model.*;

public class EntryPanel extends JPanel {

    private JTextField txtPlate;
    private JComboBox<String> comboVehicleType;
    private JComboBox<String> comboSpot;
    private JTextArea textArea;

    public EntryPanel() {

        setLayout(new BorderLayout(15,15));
        setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        // ===== Title =====
        JLabel title = new JLabel("Vehicle Entry System", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        // ===== Center Form =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Entry Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8,8,8,8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtPlate = new JTextField(15);

        comboVehicleType = new JComboBox<>(new String[]{
                "Car", "Motorcycle", "VIPCar"
        });

        comboSpot = new JComboBox<>(new String[]{
                "F1-R1-S1", "F1-R1-S2", "F1-R2-S1"
        }); // 之后可改成动态加载

        JButton btnPark = new JButton("Park Vehicle");
        btnPark.setBackground(new Color(0,120,215));
        btnPark.setForeground(Color.WHITE);

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Plate Number:"), gbc);

        gbc.gridx = 1;
        formPanel.add(txtPlate, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Vehicle Type:"), gbc);

        gbc.gridx = 1;
        formPanel.add(comboVehicleType, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Select Spot:"), gbc);

        gbc.gridx = 1;
        formPanel.add(comboSpot, gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        formPanel.add(btnPark, gbc);

        add(formPanel, BorderLayout.CENTER);

        // ===== Receipt Area =====
        textArea = new JTextArea(8,30);
        textArea.setEditable(false);
        textArea.setBorder(BorderFactory.createTitledBorder("Ticket"));
        add(new JScrollPane(textArea), BorderLayout.SOUTH);

        // ===== Button Action =====
        btnPark.addActionListener(e -> handleEntry());
    }

    private void handleEntry() {

        try {
            String plate = txtPlate.getText().trim();
            String type = comboVehicleType.getSelectedItem().toString();
            String spotId = comboSpot.getSelectedItem().toString();

            if(plate.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Plate number required!");
                return;
            }

            Vehicle vehicleObj;

            switch (type) {
                case "Car":
                    vehicleObj = new Car(plate);
                    break;
                case "Motorcycle":
                    vehicleObj = new Motorcycle(plate);
                    break;
                case "VIPCar":
                    vehicleObj = new VIPCar(plate);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid type");
            }

            Ticket ticket = ParkingLot.getInstance()
                    .parkVehicleAt(spotId, vehicleObj);

            textArea.setText(ticket.toString());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage());
        }
    }
}
