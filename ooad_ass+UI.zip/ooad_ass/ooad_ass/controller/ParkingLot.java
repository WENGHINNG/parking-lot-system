package controller;

import model.*;
import strategy.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.*;

// 必须实现 Serializable 才能被整个存进文件
public class ParkingLot implements Serializable {
    private static final long serialVersionUID = 1L;
    private static ParkingLot instance;

    private List<ParkingSpot> spots;
    private FineStrategy fineStrategy;
    private double totalRevenue;
    // Requirement 4: Fines are linked to license plate
    private Map<String, Double> outstandingFines;

    // Requirement d: Data Management (Using File System Database)
    private static final String DB_FILE = "parking_db.ser";

    private ParkingLot() {
        // 尝试加载数据，如果加载失败（第一次运行），就初始化新数据
        if (!loadData()) {
            System.out.println("No database found. Initializing new data.");
            spots = new ArrayList<>();
            totalRevenue = 0.0;
            outstandingFines = new HashMap<>();
            fineStrategy = new FixedFineStrategy();
            initializeMockData();
        } else {
            System.out.println("Database loaded successfully.");
        }
    }

    public static ParkingLot getInstance() {
        if (instance == null) {
            instance = new ParkingLot();
        }
        return instance;
    }

    // 队友 B 注意：请在这里扩展到 5 层楼
    private void initializeMockData() {
        // Floor 1
        spots.add(new ParkingSpot("F1-R1-S1", SpotType.COMPACT, 2.0));
        spots.add(new ParkingSpot("F1-R1-S2", SpotType.REGULAR, 5.0));
        spots.add(new ParkingSpot("F1-R2-S1", SpotType.HANDICAPPED, 2.0));
        // Floor 2
        spots.add(new ParkingSpot("F2-R1-S1", SpotType.REGULAR, 5.0));
        spots.add(new ParkingSpot("F2-R1-S2", SpotType.RESERVED, 10.0));
    }

    // === Database Save (每次变动后调用) ===
    public void saveData() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(DB_FILE))) {
            out.writeObject(spots);
            out.writeObject(outstandingFines);
            out.writeObject(totalRevenue);
            out.writeObject(fineStrategy);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // === Database Load (启动时调用) ===
    @SuppressWarnings("unchecked")
    private boolean loadData() {
        File f = new File(DB_FILE);
        if (!f.exists())
            return false;

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(DB_FILE))) {
            this.spots = (List<ParkingSpot>) in.readObject();
            this.outstandingFines = (Map<String, Double>) in.readObject();
            this.totalRevenue = (double) in.readObject();
            this.fineStrategy = (FineStrategy) in.readObject();
            return true;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    // === Entry System ===
    public Ticket parkVehicle(Vehicle v) {
        ParkingSpot spot = findAvailableSpot(v.getType());
        if (spot == null)
            return null;
        return parkToSpot(spot, v);
    }

    // Requirement 3: User selects a spot
    public Ticket parkVehicleAt(String spotId, Vehicle v) {
        ParkingSpot spot = null;
        for (ParkingSpot s : spots) {
            if (s.getSpotId().equals(spotId)) {
                spot = s;
                break;
            }
        }

        if (spot == null || !spot.isAvailable() || !isSpotSuitable(spot, v.getType()))
            return null;
        return parkToSpot(spot, v);
    }

    private Ticket parkToSpot(ParkingSpot spot, Vehicle v) {
        spot.park(v);
        saveData(); // <--- Auto Save
        return new Ticket(v.getPlateNo(), spot.getSpotId(), v.getEntryTime());
    }

    // === Exit System ===
    public Payment exitVehicle(String plateNo, boolean payFine, PaymentMethod method) {
        ParkingSpot targetSpot = null;
        for (ParkingSpot spot : spots) {
            if (!spot.isAvailable() && spot.getCurrentVehicle().getPlateNo().equals(plateNo)) {
                targetSpot = spot;
                break;
            }
        }

        if (targetSpot == null)
            return null;

        Vehicle v = targetSpot.getCurrentVehicle();
        LocalDateTime now = LocalDateTime.now();

        long minutes = Duration.between(v.getEntryTime(), now).toMinutes();
        double hours = Math.ceil(minutes / 60.0);
        if (hours == 0)
            hours = 1;

        // 1. Calculate Parking Fee
        double parkingFee = 0.0;
        if (v.getType() == VehicleType.HANDICAPPED) {
            if (targetSpot.getType() == SpotType.HANDICAPPED)
                parkingFee = 0.0;
            else
                parkingFee = hours * 2.0;
        } else {
            parkingFee = hours * targetSpot.getHourlyRate();
        }

        // 2. Calculate Fines
        double currentFine = 0.0;

        // Fine A: Overstay
        double hoursOverstayed = hours > 24 ? hours - 24 : 0;
        currentFine += fineStrategy.calculateFine(hoursOverstayed);

        // Fine B: Reserved Misuse (Req 4: stays in reserved without reservation)
        // Logic: Only VIP can stay in Reserved without fine.
        if (targetSpot.getType() == SpotType.RESERVED && v.getType() != VehicleType.VIP) {
            currentFine += 50.0;
        }

        double previousFine = outstandingFines.getOrDefault(plateNo, 0.0);
        double totalFine = currentFine + previousFine;

        // 3. Payment Logic
        double amountPaid = 0.0;
        if (payFine) {
            amountPaid = parkingFee + totalFine;
            outstandingFines.remove(plateNo);
        } else {
            // User chooses to pay only parking fee (Req 4)
            amountPaid = parkingFee;
            outstandingFines.put(plateNo, totalFine);
        }

        totalRevenue += amountPaid;
        targetSpot.removeVehicle();

        saveData(); // <--- Auto Save

        return new Payment(v.getPlateNo(), v.getEntryTime(), now, hours, parkingFee, totalFine, amountPaid, method);
    }

    public void addOutstandingFine(String plateNo, double amount) {
        double current = outstandingFines.getOrDefault(plateNo, 0.0);
        outstandingFines.put(plateNo, current + amount);
        saveData();
    }

    private ParkingSpot findAvailableSpot(VehicleType vType) {
        for (ParkingSpot spot : spots) {
            if (spot.isAvailable() && isSpotSuitable(spot, vType)) {
                return spot;
            }
        }
        return null;
    }

    private boolean isSpotSuitable(ParkingSpot spot, VehicleType vType) {
        SpotType sType = spot.getType();
        if (vType == VehicleType.MOTORCYCLE)
            return sType == SpotType.COMPACT;
        if (vType == VehicleType.SUV)
            return sType == SpotType.REGULAR;

        // VIP: Can park anywhere (Reserved preferred)
        if (vType == VehicleType.VIP)
            return sType == SpotType.RESERVED || sType == SpotType.REGULAR || sType == SpotType.COMPACT;

        // Car: Can park anywhere (but Reserved will trigger fine)
        if (vType == VehicleType.CAR)
            return sType == SpotType.COMPACT || sType == SpotType.REGULAR || sType == SpotType.RESERVED;

        return true;
    }

    // Admin Requirements
    public void setFineStrategy(FineStrategy strategy) {
        this.fineStrategy = strategy;
        saveData();
    }

    public List<ParkingSpot> getAllSpots() {
        return spots;
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public Map<String, Double> getOutstandingFines() {
        return outstandingFines;
    }

    public double getOccupancyRate() {
        if (spots.isEmpty())
            return 0.0;
        long occupiedCount = spots.stream().filter(s -> !s.isAvailable()).count();
        return (double) occupiedCount / spots.size();
    }

    public List<ParkingSpot> getSpotsByFloor(int floorNum) {
        String prefix = "F" + floorNum;
        List<ParkingSpot> floorSpots = new ArrayList<>();
        for (ParkingSpot s : spots) {
            if (s.getSpotId().startsWith(prefix))
                floorSpots.add(s);
        }
        return floorSpots;
    }
}